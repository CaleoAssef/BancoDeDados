 create table vendas(
id_vendas int primary key auto_increment,
produto varchar (20),
valor float,
quantidade int,
datadavenda datetime,
vendedor varchar (20)
);



insert into vendas(produto,valor,quantidade,datadavenda,vendedor)
values ('Coxinha','1.00','1','2022.10.04 04.10.02','Caleo');
insert into vendas(produto,valor,quantidade,datadavenda,vendedor)
values ('Empadão','2.49','2','2022.04.01 12.09.10','Arthur');
insert into vendas(produto,valor,quantidade,datadavenda,vendedor)
values ('Sorvete','5.00','1','2021.04.01 22.04.25','Pedro');
insert into vendas(produto,valor,quantidade,datadavenda,vendedor)
values ('Chiclete','1.49','2','2020.02.01 14.01.02','Ruan');

select * from vendas order by id_vendas asc

select all valor,produto from vendas 

uptade vendas set produto = 'Pão de queijo mineiro', valor = '3.00' 
where produto = Chiclete

uptade vendas set datadavendas = '2022.01.05 12.09.10' where produto = Empadão

delete from vendas where valor < 5
select * from vendas where valor > 5