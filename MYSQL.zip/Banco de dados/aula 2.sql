-- demo.phpmyadmin.net

-- comando para criar um database
create database aula2;

-- comando para selecionar o database
use aula1;

-- comando para criar uma tabela
create table aquecimentoglobal(
	cod_aquecimento int primary key auto_increment,
    pais varchar(20),
    co2 int,
    meta int,
    percentual float
);

-- comando para inserir um valor na tabela criada
insert into aquecimentoglobal(pais,co2,meta,percentual)
values('Brasil',150000,50000,25.0);